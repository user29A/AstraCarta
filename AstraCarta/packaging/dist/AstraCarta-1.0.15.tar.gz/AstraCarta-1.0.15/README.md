# AstraCarta

See https://github.com/user29A/astracarta

Searches a catalogue using AstroQuery for bright sources in an image field with useful search parameters.

See the Github Wiki for details on usage and options:

https://github.com/user29A/AstraCarta/wiki

This project was undertaken with the financial support of the Canadian Space Agency.